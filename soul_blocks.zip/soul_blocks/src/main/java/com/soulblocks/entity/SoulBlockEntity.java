package com.soulblocks.entity;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.util.UUID;

public class SoulBlockEntity extends PathAwareEntity {
    private static final TrackedData<BlockState> BLOCK =
            DataTracker.registerData(SoulBlockEntity.class, TrackedDataHandlerRegistry.BLOCK_STATE);

    private UUID ownerUuid;

    public SoulBlockEntity(EntityType<? extends SoulBlockEntity> type, World world) {
        super(type, world);
        this.moveControl = new FlightMoveControl(this, 10, true);
        this.setNoGravity(true);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createSoulAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.6)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(BLOCK, Blocks.STONE.getDefaultState());
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new FollowOwnerGoal(this));
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        return new BirdNavigation(this, world);
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    public BlockState getBlock() {
        return this.dataTracker.get(BLOCK);
    }

    public void setBlock(BlockState state) {
        this.dataTracker.set(BLOCK, state);
    }

    public void setOwner(UUID uuid) {
        this.ownerUuid = uuid;
    }

    public PlayerEntity getOwner() {
        return ownerUuid == null ? null : this.getWorld().getPlayerByUuid(ownerUuid);
    }

    // Sneak + right click with an empty hand: turn the ghost back into a block item.
    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (player.isSneaking() && player.getStackInHand(hand).isEmpty()) {
            if (!this.getWorld().isClient) {
                this.dropStack(new ItemStack(getBlock().getBlock()));
                this.discard();
            }
            return ActionResult.SUCCESS;
        }
        return super.interactMob(player, hand);
    }

    @Override
    public void onDeath(DamageSource source) {
        if (!this.getWorld().isClient) {
            this.dropStack(new ItemStack(getBlock().getBlock()));
        }
        super.onDeath(source);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putString("GhostBlock", Registries.BLOCK.getId(getBlock().getBlock()).toString());
        if (ownerUuid != null) {
            nbt.putUuid("Owner", ownerUuid);
        }
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("GhostBlock")) {
            Identifier id = Identifier.tryParse(nbt.getString("GhostBlock"));
            if (id != null) {
                Block block = Registries.BLOCK.get(id);
                setBlock(block.getDefaultState());
            }
        }
        if (nbt.containsUuid("Owner")) {
            ownerUuid = nbt.getUuid("Owner");
        }
    }
}
