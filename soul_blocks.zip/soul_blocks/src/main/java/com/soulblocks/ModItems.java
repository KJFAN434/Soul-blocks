package com.soulblocks;

import com.soulblocks.item.SoulItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item SOUL = Registry.register(
            Registries.ITEM,
            Identifier.of(SoulBlocks.MOD_ID, "soul"),
            new SoulItem(new Item.Settings().maxCount(16)));

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> entries.add(SOUL));
    }
}
