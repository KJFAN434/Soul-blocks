package com.soulblocks.client;

import com.soulblocks.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class SoulBlocksClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.SOUL_BLOCK, SoulBlockRenderer::new);
    }
}
