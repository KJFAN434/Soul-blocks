SOUL BLOCKS (Fabric 1.21.1)

REQUIREMENTS: Java 21 JDK, IntelliJ IDEA (Community is fine)

BUILD:
1. Unzip this folder.
2. Open it in IntelliJ IDEA (File > Open > select the soul_blocks folder). Let Gradle import finish.
3. Open the Gradle panel (elephant icon, right side) > Tasks > build > build (double click).
4. Your mod file: build/libs/soul_blocks-1.0.0.jar  (NOT the "-sources" one)
5. Put it in the mods folder together with Fabric API for 1.21.1.

USE IN GAME:
- Smelt Soul Sand in a Blast Furnace -> Soul
- Right click a block with Soul -> tiny floating ghost block that follows you
- Sneak + right click it with an empty hand -> get the block back
