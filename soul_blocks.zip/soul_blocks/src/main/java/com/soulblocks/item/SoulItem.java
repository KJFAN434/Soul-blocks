package com.soulblocks.item;

import com.soulblocks.ModEntities;
import com.soulblocks.entity.SoulBlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class SoulItem extends Item {
    public SoulItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        BlockState state = world.getBlockState(pos);

        // Skip air, unbreakable blocks (bedrock...) and blocks with inventories/data (chests, furnaces...)
        if (state.isAir() || state.getHardness(world, pos) < 0 || world.getBlockEntity(pos) != null) {
            return ActionResult.FAIL;
        }
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }

        SoulBlockEntity ghost = ModEntities.SOUL_BLOCK.create(world);
        if (ghost == null) {
            return ActionResult.FAIL;
        }

        PlayerEntity player = context.getPlayer();
        ghost.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY() + 0.3, pos.getZ() + 0.5, 0.0f, 0.0f);
        ghost.setBlock(state.getBlock().getDefaultState());
        if (player != null) {
            ghost.setOwner(player.getUuid());
        }

        world.removeBlock(pos, false);
        world.spawnEntity(ghost);
        world.playSound(null, pos, SoundEvents.BLOCK_SOUL_SAND_BREAK, SoundCategory.PLAYERS, 1.0f, 1.3f);

        if (player == null || !player.isCreative()) {
            context.getStack().decrement(1);
        }
        return ActionResult.SUCCESS;
    }
}
